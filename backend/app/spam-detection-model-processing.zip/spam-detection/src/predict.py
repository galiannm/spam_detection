"""
TfidVectorizer: turns text into vectors for ML
cosine_similarity: computes how 'similar' two vectors are
"""
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB      
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report
import joblib

names = ["ham", "spam"]

def prediction_NB(x, y):
    print("="*30)
    print("Model: MultinomialNB")
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.1, random_state=42)
    model = MultinomialNB()
    model.fit(x_train, y_train)

    predicted = model.predict(x_test) 
    # for x in range(len(predicted)):
    #     print(f"Predicted: {names[predicted[x]]} | Actual: {names[y_test[x]]}")

    print("Accuracy:", accuracy_score(y_test, predicted))
    print("\nClassification Report:")
    print(classification_report(y_test, predicted, target_names=names))

    joblib.dump(model, 'models/spam_model_NB.pkl')

# ===================================================================================

def prediction_logReg(x, y):
    print("="*30)
    print("Model: Logistic Regression")
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.1, random_state=42)
    model = LogisticRegression(max_iter=1000)
    model.fit(x_train, y_train)

    predicted = model.predict(x_test) 

    print("Accuracy:", accuracy_score(y_test, predicted))
    print("\nClassification Report:")
    print(classification_report(y_test, predicted, target_names=names))

# ===================================================================================

def prediction_RF(x, y):
    print("="*30)
    print("Model: Random Forest Classifier")
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.1, random_state=42)
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(x_train, y_train)

    predicted = model.predict(x_test) 

    print("Accuracy:", accuracy_score(y_test, predicted))
    print("\nClassification Report:")
    print(classification_report(y_test, predicted, target_names=names))

# ===================================================================================

def prediction_SVC(x, y):
    print("="*30)
    print("Model: SVC (support vector machines)")
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.1)
    x_train = x_train.toarray()
    x_test = x_test.toarray()
    model = SVC()
    model.fit(x_train, y_train)

    predicted = model.predict(x_test)
    print("Accuracy:", accuracy_score(y_test, predicted))
    print("\nClassification Report:")
    print(classification_report(y_test, predicted, target_names=names))

# ===================================================================================

def prediction_linearSVC(x, y):
    print("="*30)
    print("Model: Linear SVC")
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.1)
    x_train = x_train.toarray()
    x_test = x_test.toarray()
    model = LinearSVC()
    model.fit(x_train, y_train)

    predicted = model.predict(x_test)
    print("Accuracy:", accuracy_score(y_test, predicted))
    print("\nClassification Report:")
    print(classification_report(y_test, predicted, target_names=names))
    
    joblib.dump(model, 'models/spam_model_linearSVC.pkl')

# ===================================================================================

def email_prediction_NB(model, vectorizer, input):
    x = vectorizer.transform([input])
    prediction = model.predict(x)[0]
    label = "spam" if prediction == 1 else "ham"
    return label