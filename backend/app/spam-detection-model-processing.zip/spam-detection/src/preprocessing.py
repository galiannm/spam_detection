"""
TfidVectorizer: turns text into vectors for ML
cosine_similarity: computes how 'similar' two vectors are
"""
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd
from sklearn import preprocessing
import joblib

def load_data(filepath):
    df = pd.read_csv(filepath, sep='\t', names=['label', 'message'])
    return df

def process_label(data):
    le = preprocessing.LabelEncoder()
    label = le.fit_transform(list(data["label"]))
    return label

def process_message(data):
    vectorizer = TfidfVectorizer(
        stop_words='english',
        lowercase=True,    # convert to lower case
        ngram_range=(1,2), # unigrams and bigrams
        min_df=2,          # igore words that appear in fewer than 2 mess
        max_df=0.9,        # -------------------------- more than 90% of mess
        sublinear_tf=True  # log scale
        )
    tfidf_matrix = vectorizer.fit_transform(data['message'])
    joblib.dump(vectorizer, 'models/vectorizer.pkl')
    return tfidf_matrix
