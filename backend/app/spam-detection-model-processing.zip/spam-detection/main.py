from src.preprocessing import load_data, process_label, process_message
from src.predict import prediction_NB, prediction_logReg, prediction_RF, prediction_linearSVC, prediction_SVC ,email_prediction_NB
import joblib

data = load_data('spam-data/SMSSpamCollection.csv')

x = process_message(data)
y = process_label(data)

# general prediction
prediction_NB(x, y) # second best 
# prediction_logReg(x, y)
# prediction_RF(x, y)
# prediction_SVC(x, y) # best but very slow
prediction_linearSVC(x, y) # best and fast

model_linearSVC = joblib.load('models/spam_model_linearSVC.pkl')
vectorizer = joblib.load('models/vectorizer.pkl')

# predict an input
input = input("Enter an email: ")

prediction = email_prediction_NB(model_linearSVC, vectorizer, input)
print(f"The model predicted: {prediction}")
